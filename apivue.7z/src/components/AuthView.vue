<template>
  <div>
    <h1>{{message}}</h1>
    <div v-if="state.mno">
      <span class="title">번호</span> : {{state.mno}}<br>
      <span class="title">이름</span> : {{state.name}}<br>
      <span class="title">Email</span> : {{state.email}}<br>
      <span class="title">Mobile</span> : {{state.mobile}}<br>
    </div>
  </div>
</template>

<script>
import { onMounted, onUpdated } from 'vue'
import { reactive } from '@vue/reactivity'
import axios from 'axios'

export default {
  name: 'AuthView',
  setup(){
    onMounted(() => { handleGetAuth(); })
    onUpdated(() => { handleGetAuth(); })
    const state = reactive({
      mno : sessionStorage.getItem("mno"),
      name: '',
      email: '',
      mobile: '',
      token : sessionStorage.getItem("TOKEN"),
    });
    const handleGetAuth = async() => {
      const url ='/api/getAuth'
      const headers = {"Content-Type" : "application/json", "token": state.token}
      const body ={mno : Number(state.mno),}
      await axios.post(url, body, {headers}).then(function(res){
        if(res.status === 200){
          state.name = res.data.dto.name;
          state.email = res.data.dto.email;
          state.mobile = res.data.dto.mobile;
        }
      })
    }
    return {message: 'View Authenticaton', state, handleGetAuth}
  }
}
</script>

<style>

</style>