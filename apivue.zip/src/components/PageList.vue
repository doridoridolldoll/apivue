<template>
  <div>
    <h1>{{ message }}</h1>
    <Table
      :dtoList="state.dtoList"
      :page="state.page"
      :prev="state.prev"
      :next="state.next"
      :start="state.start"
      :end="state.end"
      :pageList="state.pageList"
      :totalPage="state.totalPage"
    />
  </div>
</template>

<script>
import { onMounted } from 'vue'
import { reactive } from '@vue/reactivity'
import axios from 'axios'
import Table from './Table.vue'

export default {
  name: 'ThePageList',
  components: { Table },
  setup() {
    onMounted(() => {
      handleGetPageList()
    })
    const state = reactive({
      dtoList: '',
      page: '',
      prev: '',
      next: '',
      start: '',
      end: '',
      pageList: '',
      totalPage: '',
      email: sessionStorage.getItem('email'),
      token: sessionStorage.getItem('TOKEN'),
    })
    const handleGetPageList = async () => {
      const url = '/apiserverex/api/get-page-list'
      const headers = {
        'Content-Type': 'application/json',
        Authorization: state.token,
        token: state.token,
      }
      const body = { email: state.email }
      await axios.post(url, body, { headers }).then(function (res) {
        if (res.status === 200) {
          console.log(res.data)
          state.dtoList = res.data.dtoList
          state.page = res.data.page
          state.prev = res.data.prev
          state.next = res.data.next
          state.start = res.data.start
          state.end = res.data.end
          state.pageList = res.data.pageList
          state.totalPage = res.data.totalPage
        }
      })
    }
    return { message: 'Page List', state, handleGetPageList }
  },
}
</script>

<style>
</style>
