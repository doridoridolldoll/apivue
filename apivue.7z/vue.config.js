const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true
})

//vue.config.js 수정하면 반드시 node서버를 restart!
const target = 'http://localhost:9090/apiserverex'
module.exports = {
  devServer: {
    port: 8080,
    proxy : {
      "/api": {target, changeOrigin: true}
    }
  }
}