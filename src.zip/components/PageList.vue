<template>
  <div>
    <h1>{{ message }} {{ counter }}</h1>
    <button @click="inc">Increment</button>
    <Table
      :dtoList="state.dtoList"
      :page="state.page"
      :prev="state.prev"
      :next="state.next"
      :start="state.start"
      :end="state.end"
      :pageList="state.pageList"
      :totalPage="state.totalPage"
      @onPageChange="handleGetPageList"
    />
  </div>
</template>

<script>
import { onMounted } from 'vue'
import { reactive } from '@vue/reactivity'
import Table from './Table.vue'
import axios from 'axios'
import { computed } from 'vue'
import { useStore } from 'vuex'

export default {
  name: 'ThePageList',
  components: { Table },
  setup() {
    const store = useStore()
    const counter = computed(function () {
      return store.state.counter
    })
    const inc = function () {
      store.commit('setCounter', counter.value + 1)
    }
    onMounted(() => {
      handleGetPageList(state.page)
    })
    const state = reactive({
      dtoList: '',
      page: '',
      prev: '',
      next: '',
      start: '',
      end: '',
      pageList: '',
      totalPage: '',
      email: sessionStorage.getItem('email'),
      token: sessionStorage.getItem('TOKEN'),
    })
    const handleGetPageList = async (value) => {
      state.page = value === '' ? 1 : value
      // console.log(">>>"+state.page+"<<<")
      const url = '/apiserverex/api/get-page-list'
      const headers = {
        'Content-Type': 'application/json',
        Authorization: state.token,
        token: state.token,
      }
      const body = { page: state.page }
      await axios.post(url, body, { headers }).then(function (res) {
        if (res.status === 200) {
          console.log(res.data)
          state.dtoList = res.data.dtoList
          state.page = res.data.page
          state.prev = res.data.prev
          state.next = res.data.next
          state.start = res.data.start
          state.end = res.data.end
          state.pageList = res.data.pageList
          state.totalPage = res.data.totalPage
        }
      })
    }
    const onPageChange = function (value) {
      state.page = value
      alert(value)
      // handleGetPageList()
    }
    return {
      message: 'Page List',
      state,
      counter,
      inc,
      handleGetPageList,
      onPageChange,
    }
  },
}
</script>

<style></style>
