<template>
  <div>
    <h1>[ {{message}} ]</h1>

  </div>
</template>

<script>
export default {
  name: 'TheHome',
  data(){
    return {message: 'Home'}
  }
}
</script>

<style>

</style>