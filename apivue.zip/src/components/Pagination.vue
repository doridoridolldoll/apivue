<template>
  <div>
    <ul class="pagination h-20 justify-content-center align-items-center">
      <li class="page-item " >
        <a href="#" class="page-link" tabindex="-1">Previous</a>
      </li>
      <li class="page-item " v-for="(pg, i) in pageList" :key="(pg, i)">
        <a href="#" class="page-link">{{pg}}</a>
      </li>
      <li class="page-item ">
        <a href="#" class="page-link">Next</a>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'ThePagination',
  props: ['page','prev','next','start','end','pageList','totalPage'],
  setup(){
  },
  data(){
    return {message: 'Pagination'}
  }
}
</script>

<style>
  .page-item{width: 50px;}
  .page-item:first-child{width: 80px;}
  .page-item:last-child{width: 80px;}
</style>
