const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
})

//vue.config.js 수정하면 반드시 node서버를 restart!
const target = 'http://localhost:9090'
module.exports = {
  devServer: {
    port: 8080,
    proxy: {
      '/apiserverex/api': { target, changeOrigin: true },
    },
  },
  publicPath: '/apiserverex',
  outputDir:
    'D:/classSpringBoot/workspace/apiserverex/src/main/resources/static',
}
