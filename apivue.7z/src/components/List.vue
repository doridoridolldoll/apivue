<template>
  <div>
    <h1>{{message}}</h1>
  </div>
</template>

<script>
export default {
  name: 'TheList',
  data(){
    return {message: 'List'}
  }
}
</script>

<style>

</style>